package com.example.facedetection;

import android.hardware.Camera;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import static android.hardware.Camera.open;


public class MainActivity  extends Activity {

        private Camera mCamera;
        private CameraPreview mPreview;
        private Camera.PictureCallback mPicture;
        private ImageButton capture, switchCamera;
        private Context myContext;
        private LinearLayout cameraPreview;
        private boolean cameraFront = false;
        public static Bitmap bitmap;
        private  int cameraIdFromBackPressed;
        private String facing;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_main);

                getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                myContext = this;
                mCamera =  Camera.open();
                mCamera.setDisplayOrientation(90);
                cameraPreview = (LinearLayout) findViewById(R.id.cPreview);
                mPreview = new CameraPreview(myContext, mCamera);
                cameraPreview.addView(mPreview);

                capture = findViewById(R.id.btnCam);
                capture.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                mCamera.takePicture(null, null, getPictureCallback());
                        }
                });

                switchCamera = findViewById(R.id.btnSwitch);
                switchCamera.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                                //get the number of cameras
                                int camerasNumber = Camera.getNumberOfCameras();
                                if (camerasNumber > 1) {
                                        //release the old camera instance
                                        //switch camera, from the front and the back and vice versa

                                        releaseCamera();
                                        chooseCamera();
                                } else {

                                }
                        }
                });

                mCamera.startPreview();

        }

        private int findFrontFacingCamera() {

                int cameraId = -1;
                // Search for the front facing camera
                int numberOfCameras = Camera.getNumberOfCameras();
                for (int i = 0; i < numberOfCameras; i++) {
                        Camera.CameraInfo info = new Camera.CameraInfo();
                        Camera.getCameraInfo(i, info);
                        if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                                cameraId = i;
                                cameraFront = true;
                                break;
                        }
                }
                return cameraId;

        }

        private int findBackFacingCamera() {
                int cameraId = -1;
                //Search for the back facing camera
                //get the number of cameras
                int numberOfCameras = Camera.getNumberOfCameras();
                //for every camera check
                for (int i = 0; i < numberOfCameras; i++) {
                        Camera.CameraInfo info = new Camera.CameraInfo();
                        Camera.getCameraInfo(i, info);
                        if (info.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                                cameraId = i;
                                cameraFront = false;
                                break;

                        }

                }
                return cameraId;
        }

        public void onResume() {

                super.onResume();
                if(mCamera == null && facing.equalsIgnoreCase("front")) {
                        mCamera = open(findFrontFacingCamera());
                        mCamera.setDisplayOrientation(90);
                        mPicture = getPictureCallback();
                        mPreview.refreshCamera(mCamera);
                        Log.d("nu", "null");
                }else if(mCamera == null && facing.equalsIgnoreCase("back")){
                        mCamera = open(findBackFacingCamera());
                        mCamera.setDisplayOrientation(90);
                        mPicture = getPictureCallback();
                        mPreview.refreshCamera(mCamera);
                }
                else {
                        Log.d("nu","no null");
                }

        }

        public void chooseCamera() {
                //if the camera preview is the front
                if (cameraFront) {
                        int cameraId = findBackFacingCamera();
                        if (cameraId >= 0) {
                                //open the backFacingCamera
                                //set a picture callback
                                //refresh the preview
                                facing = "back";
                                mCamera = open(cameraId);
                                mCamera.setDisplayOrientation(90);
                                mPicture = getPictureCallback();
                                mPreview.refreshCamera(mCamera);
                        }
                } else {
                        int cameraId = findFrontFacingCamera();
                        if (cameraId >= 0) {
                                //open the backFacingCamera
                                //set a picture callback
                                //refresh the preview
                                facing = "front";
                                mCamera = open(cameraId);
                                mCamera.setDisplayOrientation(90);
                                mPicture = getPictureCallback();
                                mPreview.refreshCamera(mCamera);
                        }
                }
        }

        @Override
        protected void onPause() {
                super.onPause();
                //when on Pause, release camera in order to be used from other applications
                releaseCamera();
        }

        private void releaseCamera() {
                // stop and release camera
                if (mCamera != null) {
                        mCamera.stopPreview();
                        mCamera.setPreviewCallback(null);
                        mCamera.release();
                        mCamera = null;
                }
        }

        private Camera.PictureCallback getPictureCallback() {
                Camera.PictureCallback picture = new Camera.PictureCallback() {
                        @Override
                        public void onPictureTaken(byte[] data, Camera camera) {
                                bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                                Intent intent = new Intent(MainActivity.this,PictureActivity.class);
                                intent.putExtra("CameraFacing", facing);
                                startActivity(intent);
                        }
                };
                return picture;
        }

        @Override
        public void onBackPressed() {
                super.onBackPressed();
        }
}
