package com.example.loginusingfirebase;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class CreateEmployeeActivity extends Activity implements View.OnClickListener {
    private EditText empIDET, empNameET, empDepartmentET;
    private EmployeePOJO employeePOJO;
    private Button createEmployeeNowBtn;
    private DatabaseReference database;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_employee_form);

        // Finding views by ids
        empIDET = findViewById(R.id.empID);
        empNameET = findViewById(R.id.empName);
        empDepartmentET = findViewById(R.id.empDepartment);
        createEmployeeNowBtn = findViewById(R.id.createEmployeeNowBtn);

        // Writing to DataBase
        createEmployeeNowBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.createEmployeeNowBtn){

            //DatabaseReference myRef = database.getReference();

            database = FirebaseDatabase.getInstance().getReference("employee");
            // Setting employee info to object

            employeePOJO = new EmployeePOJO(empIDET.getText().toString(), empNameET.getText().toString(), empDepartmentET.getText().toString());
            Log.e("Employee: " , empIDET.getText().toString() + " " + empNameET.getText().toString() + " " + empDepartmentET.getText().toString());
//            employeePOJO.setEmpID(empID.getText().toString());
//            employeePOJO.setEmpName(empName.getText().toString());
//            employeePOJO.setEmpDepartment(empDepartment.getText().toString());

            database.push().setValue(employeePOJO);

            Toast.makeText(CreateEmployeeActivity.this,
                    "Employee Created Succesfully!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(CreateEmployeeActivity.this, SignedInActivity.class);
            startActivity(intent);
        }
    }
}
