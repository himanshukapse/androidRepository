package com.example.loginusingfirebase;

import android.view.View;
import android.widget.TextView;


import androidx.recyclerview.widget.RecyclerView;

public  class MyViewHolder extends RecyclerView.ViewHolder {

    View view;
    public TextView tv1;
    public TextView tv2;
    public TextView tv3;

    public MyViewHolder(View itemView) {
        super(itemView);
        view = itemView;
        tv1 = itemView.findViewById(R.id.userID);
        tv2 = itemView.findViewById(R.id.userName);
        tv3 = itemView.findViewById(R.id.userDepartment);
    }

    public void setDetails(String ID, String name, String department){

        tv1.setText("Employee ID: " + ID);
        tv2.setText("Employee Name: "+name);
        tv3.setText("Employee Dept.: "+ department);
    }
}