package com.example.loginusingfirebase;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private FirebaseAuth mAuth;
    private EditText em, pass;
    private TextView registerLink;
    private String email, password, name, mailId;
    private Button signInBtn;
    private ProgressBar signin_progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        em = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        signin_progress=findViewById(R.id.signin_progress);
        signInBtn = findViewById(R.id.signInBtn);
        registerLink = findViewById(R.id.registerLink);
        mAuth = FirebaseAuth.getInstance();
//        FirebaseUser currentUser = mAuth.getCurrentUser();
//        updateUI(currentUser);


        signInBtn.setOnClickListener(this);
        registerLink.setOnClickListener(this);

    }


    // General UI update  method
//    private void updateUI(FirebaseUser currentUser) {
//        if(currentUser!=null){
//
//            signin_progress.setVisibility(View.INVISIBLE);
//            startActivity(intent);
//        }
//        else if(currentUser==null){
//            setContentView(R.layout.activity_main);
//        }
//    }

    @Override
    public void onClick(View v) {

        if(v.getId()==R.id.signInBtn){
            signin_progress.setVisibility(View.VISIBLE);
            email = em.getText().toString();
            password = pass.getText().toString();

            // sign in
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "Login Successful.",
                                        Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, SignedInActivity.class);
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    signin_progress.setVisibility(View.INVISIBLE);
                                    startActivity(intent);
                            } else {
                                Toast.makeText(MainActivity.this, "Login failed.",
                                        Toast.LENGTH_SHORT).show();
                                signin_progress.setVisibility(View.INVISIBLE);

                            }
                        }
                    });

        }
        else if(v.getId()==R.id.registerLink){
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        }
    }
}
