package com.example.loginusingfirebase;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignedInActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView welcomeText;
    private int ch;
    private Button signOut, createEmployeeBtn, listEmployeeBtn;
    private String email, userName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signed_in);
        welcomeText = findViewById(R.id.welcomeText);
        signOut = findViewById(R.id.signOutBtn);
        createEmployeeBtn = findViewById(R.id.createEmployeeBtn);
        listEmployeeBtn = findViewById(R.id.listEmployeeBtn);
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // Name, email address, and profile photo Url
            email = user.getEmail();
            ch = email.indexOf('@');
            userName = email.substring(0,ch);
            welcomeText.setText("Hello, " + userName);
        }
        createEmployeeBtn.setOnClickListener(this);
        listEmployeeBtn.setOnClickListener(this);
        signOut.setOnClickListener(this);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder=new AlertDialog.Builder(SignedInActivity.this);
        builder.setMessage("Do you want to exit?");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent i=new Intent(SignedInActivity.this, MainActivity.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.signOutBtn){
            AlertDialog.Builder builder=new AlertDialog.Builder(SignedInActivity.this);
            builder.setMessage("Do you want to Sign Out?");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    Intent i=new Intent(SignedInActivity.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }
            });
            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });
            AlertDialog alert=builder.create();
            alert.show();
        }
        else if(v.getId()==R.id.createEmployeeBtn){
            Intent intent = new Intent(SignedInActivity.this, CreateEmployeeActivity.class);
            startActivity(intent);
        }
        else if(v.getId()==R.id.listEmployeeBtn){
            Intent intent = new Intent(SignedInActivity.this, ListUserActivity.class);
            intent.putExtra("email",email);
            startActivity(intent);
        }
    }
}
