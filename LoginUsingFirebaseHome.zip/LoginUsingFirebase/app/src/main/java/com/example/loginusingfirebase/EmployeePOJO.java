package com.example.loginusingfirebase;

import androidx.annotation.NonNull;

public class EmployeePOJO {
    private String empID;
    private String empName;
    private String empDepartment;




    public EmployeePOJO(String empID, String empName, String empDepartment) {
        this.empID = empID;
        this.empName = empName;
        this.empDepartment = empDepartment;
    }

    public EmployeePOJO(Object empID, Object empName, Object empDepartment) {
    }


    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpDepartment() {
        return empDepartment;
    }

    public void setEmpDepartment(String empDepartment) {
        this.empDepartment = empDepartment;
    }

    @NonNull
    @Override
    public String toString() {
        return super.toString();
    }
}
