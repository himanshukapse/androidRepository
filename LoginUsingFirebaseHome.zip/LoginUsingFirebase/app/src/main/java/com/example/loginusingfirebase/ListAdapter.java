package com.example.loginusingfirebase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

class ListAdapter extends  RecyclerView.Adapter<MyViewHolder> {

    private Context context;
    private List<EmployeePOJO> employeeList;
    private EmployeePOJO employeePOJO;


    public ListAdapter(Context context, List<EmployeePOJO> employeeList) {
        this.context = context;
        this.employeeList = employeeList;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.list_item, null);
        MyViewHolder viewHolder = new MyViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        employeePOJO = employeeList.get(position);
        holder.setDetails(employeePOJO.getEmpID(), employeePOJO.getEmpName(), employeePOJO.getEmpDepartment());

    }

    @Override
    public int getItemCount() {
        return employeeList.size();
    }

}
