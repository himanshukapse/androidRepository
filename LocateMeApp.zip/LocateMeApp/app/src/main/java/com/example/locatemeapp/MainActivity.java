package com.example.locatemeapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import androidx.annotation.NonNull;

public class MainActivity extends Activity implements View.OnClickListener {
    private FirebaseAuth mAuth;
    private EditText em, pass;
    private TextView registerLink;
    private String email, password, name, mailId;
    private Button signInBtn;
    private ProgressBar signin_progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        em = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        signin_progress = findViewById(R.id.signin_progress);
        signInBtn = findViewById(R.id.signInBtn);
        registerLink = findViewById(R.id.registerLink);
        mAuth = FirebaseAuth.getInstance();


        signInBtn.setOnClickListener(this);
        registerLink.setOnClickListener(this);

    }


    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.signInBtn) {
            signin_progress.setVisibility(View.VISIBLE);
            email = em.getText().toString();
            password = pass.getText().toString();

            // sign in
            mAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(MainActivity.this, "Login Successful.",
                                        Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(MainActivity.this, SignedInActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                signin_progress.setVisibility(View.INVISIBLE);
                                startActivity(intent);
                            } else {
                                Toast.makeText(MainActivity.this, "Login failed.",
                                        Toast.LENGTH_SHORT).show();
                                signin_progress.setVisibility(View.INVISIBLE);

                            }
                        }
                    });

        } else if (v.getId() == R.id.registerLink) {
            Intent intent = new Intent(MainActivity.this, RegisterActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}