package com.example.locatemeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.mapbox.mapboxsdk.location.LocationComponentActivationOptions;

public class SignedInActivity extends AppCompatActivity implements View.OnClickListener, LocationListener {
    private TextView welcomeText;
    private Location location;
    private int ch;
    protected LocationManager locationManager;
    private static final int REQUEST_LOCATION = 1;
    private Double lat, longt;
    private Button signOut, ViewMap, LocateMe, ShareMyLocation;
    private String email, userName, latitude, longitude;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signed_in);
        welcomeText = findViewById(R.id.welcomeText);
        signOut = findViewById(R.id.signOutBtn);
        ViewMap = findViewById(R.id.viewMapBtn);
        LocateMe = findViewById(R.id.locateMeBtn);
        ShareMyLocation = findViewById(R.id.shareMyLocationBtn);


        signOut.setOnClickListener(this);
        ShareMyLocation.setOnClickListener(this);
        ViewMap.setOnClickListener(this);
        LocateMe.setOnClickListener(this);
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    Activity#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for Activity#requestPermissions for more details.
            return;
        }
        location = locationManager.getLastKnownLocation(locationManager.NETWORK_PROVIDER);


    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.signOutBtn) {
            AlertDialog.Builder builder = new AlertDialog.Builder(SignedInActivity.this);
            builder.setMessage("Do you want to sign out?");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    Intent i = new Intent(SignedInActivity.this, MainActivity.class);
                    i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }
            });
            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });
            AlertDialog alert = builder.create();
            alert.show();
        } else if (v.getId() == R.id.viewMapBtn) {
            Intent intent = new Intent(SignedInActivity.this, ViewMap.class);
            startActivity(intent);
        } else if (v.getId() == R.id.locateMeBtn) {
            Intent intent = new Intent(SignedInActivity.this, LocateMeActivity.class);
            startActivity(intent);
        } else if (v.getId() == R.id.shareMyLocationBtn) {
            onLocationChanged(location);
                    //Sharing location
                    String uri = "http://maps.google.com/maps?saddr=" +lat+","+longt;
                    Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                    sharingIntent.setType("text/plain");
                    String ShareSub = "Here is my location";
                    sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, ShareSub);
                    sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, uri);
                    startActivity(Intent.createChooser(sharingIntent, "Share via"));

        }
    }


    @Override
    public void onLocationChanged(Location location) {
        lat = location.getLatitude();
        longt = location.getLongitude();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }
}
