package com.example.facedetectionofc;



import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PointF;
import android.media.MediaScannerConnection;

import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import android.media.FaceDetector;
import android.media.FaceDetector.Face;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;

import static com.example.facedetectionofc.MainActivity.bitmap;

public class PictureActivity extends Activity {
    private static final String IMAGE_DIRECTORY = "/CustomImage";
    private FaceOverlayView mFaceOverlayView;
    private TextView l, r, sm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);
        mFaceOverlayView = findViewById(R.id.face_overlay);
        l = findViewById(R.id.leftEyeProb);
        r = findViewById(R.id.rightEyeProb);
        sm = findViewById(R.id.smilingProb);

        mFaceOverlayView.setBitmap(bitmap);
        saveImage(bitmap);
        l.setText("Left Eye Open Probability: " + mFaceOverlayView.getLeftEye());
        r.setText("Right Eye Open Probability: " + mFaceOverlayView.getRightEye());
        sm.setText("Smiling Probability: " + mFaceOverlayView.getSmiling());
    }

    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.

        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance()
                    .getTimeInMillis() + ".jpg");
            f.createNewFile();   //give read write permission
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this,
                    new String[]{f.getPath()},
                    new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::--->" + f.getAbsolutePath());

            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(PictureActivity.this, MainActivity.class);
//        intent.putExtra("CameraFacing", facing);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

}
